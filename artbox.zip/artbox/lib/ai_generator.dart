import 'dart:convert';
import 'package:http/http.dart' as http;

class ImageGenerator {
  final String apiUrl = 'https://api.unsplash.com/photos/random';

  Future<String> getImage(String query) async {
    final response = await http.get(
      Uri.parse('$apiUrl?query=$query&client_id=UegSWywZw500NH80JYCus7YaYtHIRfyT1pqM6HmvvHk'),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['urls']['regular'];
    } else {
      throw Exception('Failed to fetch image');
    }
  }
}
