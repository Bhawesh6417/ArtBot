import 'package:flutter/material.dart';

class CameraUploadSection extends StatelessWidget {
  const CameraUploadSection({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text(
          'Upload Photo from Camera Roll',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        ElevatedButton(
          onPressed: () {
            // Implement logic to open camera roll and select a photo
          },
          child: const Text('Select Photo'),
        ),
        // Add code to display the selected photo
      ],
    );
  }
}
