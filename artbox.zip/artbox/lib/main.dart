import 'dart:io';

import 'package:flutter/material.dart';
import 'ai_generator.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Search App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  final ImageGenerator _imageGenerator = ImageGenerator();
  final TextEditingController _controller = TextEditingController();
  String _imageUrl = '';
  bool _isLoading = false;
  final ImagePicker _picker = ImagePicker();
  // ignore: unused_field
  String _membershipLevel = 'Basic'; 
  

  Future<void> _getImage() async {
    setState(() {
      _isLoading = true;
    });

    try {
      String query = _controller.text;
      String imageUrl = await _imageGenerator.getImage(query);

      if (mounted) {
        setState(() {
          _imageUrl = imageUrl;
        });
      }
    } catch (e) {
      debugPrint('Error fetching image: $e');
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _uploadImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imageUrl = pickedFile.path;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Search'),
        centerTitle: true, // Align title to center
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert), // Three-dot icon
            onSelected: (String value) {
              setState(() {
                _membershipLevel = value;
              });
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              const PopupMenuItem<String>(
                value: 'Basic',
                child: Text('Basic: \$9.99/month'),
              ),
              const PopupMenuItem<String>(
                value: 'Premium',
                child: Text('Premium: \$39.99/month'),
              ),
              const PopupMenuItem<String>(
                value: 'Pro',
                child: Text('Pro: \$69.99/month'),
              ),
            ],
          ),
        ],
      ),
      
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                controller: _controller,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Enter a search term',
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isLoading ? null : _getImage,
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : const Text('Search Image'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _uploadImage,
              child: const Text('Upload Image'),
            ),
            const SizedBox(height: 20),
            _imageUrl.isNotEmpty
    ? _imageUrl.startsWith('http') // Check if it's a network URL
        ? Image.network(_imageUrl) // Display using Image.network for web compatibility
        : Image.file(File(_imageUrl)) // Display using Image.file for mobile platforms
    : const Text('Basic Membership'),
          ],
        ),
      ),
    );
  }
}
