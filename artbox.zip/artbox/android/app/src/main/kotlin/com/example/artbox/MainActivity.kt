package com.example.artbox

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
